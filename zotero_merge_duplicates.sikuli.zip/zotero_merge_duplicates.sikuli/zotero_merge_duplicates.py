# set the maximum number of duplicates you want to 
# delete to a number a higher than the
# estimated number of duplicates you have:

max_number_of_duplicates = 5000

# The following line sets the sleep period between
# clicks of the merge or icon buttons to 4 seconds
# set this lower if you notice it reliably takes less
# than 4 seconds for your computer to merge a set of
# duplicates. Set it higher if your computer is slow.
# if this number is small the duplicates will 
# disappear faster:

pause_between_clicks = 4

# This is an example of the type of image sikuli will scan
# for on your desktop, and it must be present and visible
# for sikuli to see it. On my computer the toolbar for
# zotero looks like this. If yours looks different, replace
# this image with a more approprate one (use the take 
# screenshot feature in the sikuli IDE). Also, make sure
# all following images match what you see on your desktop:

zotero_main_toolbar = "1521813633962.png"

if not exists(zotero_main_toolbar):
    popup("Can't find Zotero - is Zotero open and visible on the screen?")
    exit()
while exists(zotero_main_toolbar):
    
    x = 0
    while (x < max_number_of_duplicates):
        x+=1
        if not exists("1521807755287.png"):
            
            # selecting the correct menu...
            
            click("1521807572613.png")  
            click("1521807572613.png")
            wait("1521807755287.png", 60)
            wait("1521887003631.png",20)
            sleep(pause_between_clicks)
        if exists("1522408974365.png"):
            
            # the image above indicates that the 'duplicates' 
            # folder is empty - the code will terminate
           
            popup("all recognized duplicates have been merged")
            exit()

        # The following is a set of cases for finding different
        # icons and clicking on them. There is probably a more
        # eloquent way to do this, also not all possible icons
        # are represented:
        
        elif exists("1521887003631.png"):
            click("1521887003631.png")
            sleep(pause_between_clicks)
        elif exists("1522405359339.png"):
            click("1522405359339.png")
            sleep(pause_between_clicks)
        elif exists("1522405303331.png"):   
            click("1522405303331.png")
            sleep(pause_between_clicks)
        elif exists("1522405593128.png"):   
            click("1522405593128.png") 
            sleep(pause_between_clicks)
        else:
            popup("all recognized duplicates have been merged")
            exit()
        while exists("1521813151722.png"):
            # I have skip any findFailed
            # error messages, because sometimes the merge 
            # button will disappear between execution of
            # the while statement and the following click
            # statement, throwing an error and exiting the
            # run:
            
            setFindFailedResponse(SKIP)
            click("1521813151722.png")
            sleep(pause_between_clicks)
            x+=1
          
    popup("Zotero duplicates deleted")
    exit()

        
   




